#include<stdio.h>

int main() {
printf("%s","Hello World!");
return 0;
}
