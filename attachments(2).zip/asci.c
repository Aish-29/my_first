#include<stdio.h>

int main(){
    printf("x = %d\n",'a');
    return 0;
}
