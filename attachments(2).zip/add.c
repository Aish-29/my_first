#include<stdio.h>

int main(){
    int a = 2;
    int b = 3;
    printf("The sum of two numbers a and b is : %d\n",a+b);
    return 0;
}
