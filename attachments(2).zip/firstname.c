#include<stdio.h>

int main(){
printf("Aishnaya\n");
return 0;
}
