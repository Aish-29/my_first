#include<stdio.h>

int main(){
    int i,j,k=1;
    for(i=4;i>1;i--){
        for(j=1;j<i;j++){
            printf(" ");
        }
        for(k=4;k){
    }
    printf("*\n");
    }
    return 0;
}
