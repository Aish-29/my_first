#include<stdio.h>

float main(){
    int a,b;
    printf("Enter a and b:");
    scanf("%d %d",&a,&b);
    printf("The addition of a and b is : %d\n",a+b);
    printf("The subtraction of a and b is : %d\n",a-b);
    printf("The multiplication of a and b is : %d\n",a*b);
    printf("The division of a and b is : %d\n",a/b);
    return 0.0;
}
